(function () {
  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const finePointer = window.matchMedia("(pointer: fine)").matches;

  /* ---------- page enter animation ---------- */
  document.body.classList.add("entering");

  /* ---------- active nav link ---------- */
  const current = (location.pathname.split("/").pop() || "index.html").toLowerCase();
  document.querySelectorAll(".links a").forEach((a) => {
    if (a.getAttribute("href") === current) a.classList.add("active");
  });

  /* ---------- page transitions for internal links ---------- */
  document.querySelectorAll('a[href$=".html"]').forEach((a) => {
    a.addEventListener("click", (e) => {
      if (a.target === "_blank" || e.metaKey || e.ctrlKey || e.shiftKey) return;
      e.preventDefault();
      const href = a.getAttribute("href");
      document.body.classList.add("leaving");
      setTimeout(() => (window.location.href = href), reduceMotion ? 0 : 380);
    });
  });

  /* ---------- mobile menu ---------- */
  const menuBtn = document.querySelector(".menu-btn");
  const links = document.querySelector(".links");
  if (menuBtn && links) {
    menuBtn.addEventListener("click", () => {
      menuBtn.classList.toggle("open");
      links.classList.toggle("open");
    });
  }

  /* ---------- nav style on scroll + back to top ---------- */
  const nav = document.querySelector(".nav");
  const toTop = document.querySelector(".to-top");
  const onScroll = () => {
    const y = window.scrollY;
    if (nav) nav.classList.toggle("scrolled", y > 30);
    if (toTop) toTop.classList.toggle("show", y > 600);
  };
  window.addEventListener("scroll", onScroll, { passive: true });
  onScroll();
  if (toTop) toTop.addEventListener("click", () => window.scrollTo({ top: 0, behavior: "smooth" }));

  /* ---------- typing effect ---------- */
  const typeEl = document.querySelector("[data-typing]");
  if (typeEl && !reduceMotion) {
    const words = typeEl.dataset.typing.split(",").map((w) => w.trim());
    let w = 0, c = 0, del = false;
    const tick = () => {
      const word = words[w];
      typeEl.textContent = del ? word.slice(0, c--) : word.slice(0, c++);
      let delay = del ? 40 : 95;
      if (!del && c > word.length) { del = true; delay = 1500; }
      else if (del && c < 0) { del = false; w = (w + 1) % words.length; c = 0; delay = 300; }
      setTimeout(tick, delay);
    };
    tick();
  } else if (typeEl) {
    typeEl.textContent = typeEl.dataset.typing.split(",")[0];
  }

  /* ---------- particle network in hero ---------- */
  const canvas = document.getElementById("particles");
  if (canvas && !reduceMotion) {
    const ctx = canvas.getContext("2d");
    let w, h, dots = [];
    const colors = ["34,211,160", "91,141,255", "181,123,255"];
    const resize = () => {
      const r = canvas.getBoundingClientRect();
      w = canvas.width = r.width * devicePixelRatio;
      h = canvas.height = r.height * devicePixelRatio;
      ctx.setTransform(devicePixelRatio, 0, 0, devicePixelRatio, 0, 0);
      const count = Math.min(90, Math.floor(r.width * r.height / 16000));
      dots = Array.from({ length: count }, () => ({
        x: Math.random() * r.width,
        y: Math.random() * r.height,
        vx: (Math.random() - 0.5) * 0.4,
        vy: (Math.random() - 0.5) * 0.4,
        r: Math.random() * 1.8 + 0.8,
        c: colors[Math.floor(Math.random() * colors.length)],
      }));
    };
    resize();
    window.addEventListener("resize", resize);

    let mouse = { x: -999, y: -999 };
    canvas.parentElement.addEventListener("mousemove", (e) => {
      const r = canvas.getBoundingClientRect();
      mouse.x = e.clientX - r.left;
      mouse.y = e.clientY - r.top;
    });
    canvas.parentElement.addEventListener("mouseleave", () => (mouse = { x: -999, y: -999 }));

    const draw = () => {
      const W = canvas.width / devicePixelRatio;
      const H = canvas.height / devicePixelRatio;
      ctx.clearRect(0, 0, W, H);
      for (const d of dots) {
        d.x += d.vx; d.y += d.vy;
        if (d.x < 0 || d.x > W) d.vx *= -1;
        if (d.y < 0 || d.y > H) d.vy *= -1;
      }
      for (let i = 0; i < dots.length; i++) {
        const a = dots[i];
        for (let j = i + 1; j < dots.length; j++) {
          const b = dots[j];
          const dx = a.x - b.x, dy = a.y - b.y;
          const dist = Math.hypot(dx, dy);
          if (dist < 130) {
            ctx.strokeStyle = `rgba(91,141,255,${(1 - dist / 130) * 0.25})`;
            ctx.lineWidth = 1;
            ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
          }
        }
        const md = Math.hypot(a.x - mouse.x, a.y - mouse.y);
        if (md < 150) {
          ctx.strokeStyle = `rgba(34,211,160,${(1 - md / 150) * 0.5})`;
          ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(mouse.x, mouse.y); ctx.stroke();
        }
        ctx.fillStyle = `rgba(${a.c},0.9)`;
        ctx.beginPath(); ctx.arc(a.x, a.y, a.r, 0, Math.PI * 2); ctx.fill();
      }
      requestAnimationFrame(draw);
    };
    draw();
  }

  /* ---------- cursor glow ---------- */
  const glow = document.querySelector(".cursor-glow");
  if (glow && finePointer && !reduceMotion) {
    let tx = 0, ty = 0, gx = 0, gy = 0;
    window.addEventListener("mousemove", (e) => { tx = e.clientX; ty = e.clientY; });
    const follow = () => {
      gx += (tx - gx) * 0.12;
      gy += (ty - gy) * 0.12;
      glow.style.transform = `translate(${gx}px, ${gy}px)`;
      requestAnimationFrame(follow);
    };
    follow();
  } else if (glow) {
    glow.style.display = "none";
  }

  /* ---------- 3D tilt and spotlight on cards ---------- */
  if (finePointer && !reduceMotion) {
    document.querySelectorAll(".tilt").forEach((card) => {
      card.addEventListener("mousemove", (e) => {
        const r = card.getBoundingClientRect();
        const x = e.clientX - r.left, y = e.clientY - r.top;
        const rx = ((y / r.height) - 0.5) * -8;
        const ry = ((x / r.width) - 0.5) * 8;
        card.style.transform = `perspective(900px) rotateX(${rx}deg) rotateY(${ry}deg) translateY(-4px)`;
        card.style.setProperty("--mx", x + "px");
        card.style.setProperty("--my", y + "px");
      });
      card.addEventListener("mouseleave", () => (card.style.transform = ""));
    });
  }

  /* ---------- scroll reveal ---------- */
  const revealEls = document.querySelectorAll(".reveal, .reveal-left, .reveal-right, .reveal-scale, .chip");
  if (reduceMotion || !("IntersectionObserver" in window)) {
    revealEls.forEach((el) => el.classList.add("visible"));
  } else {
    const io = new IntersectionObserver((entries) => {
      entries.forEach((e) => {
        if (e.isIntersecting) {
          const delay = parseInt(e.target.dataset.delay || 0, 10);
          setTimeout(() => e.target.classList.add("visible"), delay);
          io.unobserve(e.target);
        }
      });
    }, { threshold: 0.15, rootMargin: "0px 0px -40px 0px" });
    revealEls.forEach((el) => io.observe(el));
  }

  /* ---------- staggered children (chips and cards) ---------- */
  document.querySelectorAll("[data-stagger]").forEach((group) => {
    [...group.children].forEach((child, i) => {
      if (child.classList.contains("chip")) return;
      child.dataset.delay = i * 110;
      child.classList.add("reveal");
    });
    [...group.querySelectorAll(".chip")].forEach((chip, i) => {
      chip.dataset.delay = i * 60;
    });
  });

  /* ---------- animated counters ---------- */
  const counters = document.querySelectorAll("[data-count]");
  if (counters.length && "IntersectionObserver" in window && !reduceMotion) {
    const cio = new IntersectionObserver((entries) => {
      entries.forEach((e) => {
        if (!e.isIntersecting) return;
        const el = e.target;
        const target = parseFloat(el.dataset.count);
        const decimals = parseInt(el.dataset.decimals || 0, 10);
        const suffix = el.dataset.suffix || "";
        const dur = 1600;
        const start = performance.now();
        const step = (now) => {
          const p = Math.min((now - start) / dur, 1);
          const eased = 1 - Math.pow(1 - p, 3);
          el.textContent = (target * eased).toFixed(decimals) + suffix;
          if (p < 1) requestAnimationFrame(step);
        };
        requestAnimationFrame(step);
        cio.unobserve(el);
      });
    }, { threshold: 0.5 });
    counters.forEach((el) => cio.observe(el));
  } else {
    counters.forEach((el) => (el.textContent = el.dataset.count + (el.dataset.suffix || "")));
  }

  /* ---------- experience timeline progress line ---------- */
  const tl = document.querySelector(".timeline");
  if (tl && !reduceMotion) {
    const prog = tl.querySelector(".progress");
    const updateTl = () => {
      const r = tl.getBoundingClientRect();
      const vh = window.innerHeight;
      const visible = Math.min(Math.max(vh * 0.6 - r.top, 0), r.height);
      prog.style.height = (visible / r.height) * 100 + "%";
    };
    window.addEventListener("scroll", updateTl, { passive: true });
    updateTl();
  }

  /* ---------- project filters ---------- */
  const filters = document.querySelectorAll(".filter");
  const projects = document.querySelectorAll(".proj");
  filters.forEach((btn) => {
    btn.addEventListener("click", () => {
      filters.forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      const f = btn.dataset.filter;
      projects.forEach((p) => {
        const match = f === "all" || p.dataset.cat.split(" ").includes(f);
        p.classList.toggle("hide", !match);
        if (match) {
          p.classList.remove("visible");
          requestAnimationFrame(() => setTimeout(() => p.classList.add("visible"), 30));
        }
      });
    });
  });

  /* ---------- contact form (opens the visitor's email app) ---------- */
  const form = document.getElementById("contact-form");
  if (form) {
    form.addEventListener("submit", (e) => {
      e.preventDefault();
      const data = new FormData(form);
      const subject = encodeURIComponent("Portfolio enquiry from " + data.get("name"));
      const body = encodeURIComponent(
        data.get("message") + "\n\nFrom: " + data.get("name") + " <" + data.get("email") + ">"
      );
      window.location.href = `mailto:keshav06singh06@gmail.com?subject=${subject}&body=${body}`;
      const note = document.getElementById("sent-note");
      if (note) note.style.display = "block";
      form.reset();
    });
  }
})();
